﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaDeGestaoDeFranquiasJava.RegrasDeGestao
{
    public class Franquia
    {
        public string NomeFantasia {  get; set; }
        public string TipoFranquia { get; set; }
        public double ValorRendimento { get; set; }
        public double ValorAPagar {  get; set; }
        public int Id { get; set; }

        public int requisito = 0;
        public int condicao = 0;

        public List<Funcionario> listaFuncionario { get; set; }
        
        
        public Franquia (int id, string nomeFantasia, string tipoFranquia)
        {
            this.Id = id;
            this.NomeFantasia = nomeFantasia;
            this.TipoFranquia = tipoFranquia;

            listaFuncionario = new List<Funcionario> ();
            
        }
        public void CadastrarFuncionario()
        {
            
            while (requisito == 0)
            {
                Console.Clear();
                Console.WriteLine("*************************CADASTRAR FUNCIONARIO*************************\n\n");
                Funcionario funcionario = new Funcionario ();


                Console.Write($"°{condicao + 1}Nome....:");
                funcionario.Nome = Console.ReadLine();
                Console.Write($"\n°{condicao + 1}Genero....:");
                funcionario.Genero = Console.ReadLine();
                Console.Write($"\nEX:(dd/mm/yyyy)\n°{condicao + 1}Data de nascimento....:");
                funcionario.DataNascimento = Convert.ToDateTime(Console.ReadLine());
                Console.Write($"\n°{condicao + 1}CPF....:");
                funcionario.Cpf = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("\nINSIRA O NUMERO CORRESPONDENTE AO CARGO DESEJADO....:");
                Console.WriteLine("1 - GERENTE \n2 - CONTADOR \n3 - SECRETARIO \n4 - VENDEDOR \n" +
                    "5 - AUXILIAR DE SERVIÇOS GERAIS");
                Console.WriteLine("°");
               while (true)
                {
                    funcionario.Cargo = Console.ReadLine();
                    if (funcionario.Cargo == "1" || funcionario.Cargo == "2" || funcionario.Cargo == "3" || funcionario.Cargo == "4" || funcionario.Cargo == "5") break;
                    else Console.Write("\n!CARGO FALSO! INSIRA NOVAMENTE:");
                }
                if (funcionario.Cargo == "1") funcionario.Cargo = "GERENTE";
                else if (funcionario.Cargo == "2") funcionario.Cargo = "CONTADOR";
                else if (funcionario.Cargo == "3") funcionario.Cargo = "SECRETARIO";
                else if (funcionario.Cargo == "4") funcionario.Cargo = "VENDEDOR";
                else if (funcionario.Cargo == "5") funcionario.Cargo = "AUXILIAR";
             
                condicao++;            
               //if (condicao == 7 || condicao > 7)
               // { 
                    if (condicao == 7)
                    {
                        Console.WriteLine("REQUISITO MINIMO DE CADASTROS REALIZADO");

                    }
                    else if (condicao == 50)
                    {
                        Console.WriteLine("MÁXIMO DE CADASTROS REALIZADO"); requisito = 1;
                    }
                    Console.WriteLine("DESEJA CONTINUAR CADASTRANDO? (S/N)");
                    string resposta = Console.ReadLine();
                    if (resposta.ToUpper() != "S") requisito = 1;
               // }
               listaFuncionario.Add(funcionario);
                
            }//Fim do while
            requisito = 0;
        }//Fim CadastrarFuncionario()
        public void ConsultarDadosDaFranquia()
        {
            Console.WriteLine($"*************************DADOS DA FRANQUIA {NomeFantasia.ToUpper()}*************************\n");
            Console.WriteLine($"TIPO DA FRANQUIA.....:{TipoFranquia}\n");
            Console.WriteLine("LISTA DE FUNCIONÁRIOS: ");
            foreach (var funcionarios in listaFuncionario)
            {
                Console.WriteLine($"NOME: {funcionarios.Nome}");
                Console.WriteLine($"GÊNERO: {funcionarios.Genero}");
                Console.WriteLine($"DATA DE NASCIMENTO: {funcionarios.DataNascimento}");
                Console.WriteLine($"CPF: {funcionarios.Cpf}");
                Console.WriteLine($"SALARIO: {funcionarios.ValorDoSalario()}");
                Console.WriteLine($"CARGO: {funcionarios.Cargo}\n-");               
            }
        }//Fim ConsultarDadosDaFranquia()
        public void FiltrarFuncionariosPorNome()
        {
            Console.WriteLine("*************************FILTRO DE FUNCIONÁRIOS*************************");
            
            while (true)
            {
                Console.Write("Informe o nome do funcionário....:");
                string resposta;
                var nome = Console.ReadLine();
                var procurandoNome = listaFuncionario.Where(n => n.Nome.Contains(nome)).ToList();
                if (procurandoNome != null)
                {
                    foreach (var funcionarios in procurandoNome)
                    {
                        Console.WriteLine($"NOME: {funcionarios.Nome}");
                        Console.WriteLine($"GÊNERO: {funcionarios.Genero}");
                        Console.WriteLine($"DATA DE NASCIMENTO: {funcionarios.DataNascimento}");
                        Console.WriteLine($"CPF: {funcionarios.Cpf}");
                        Console.WriteLine($"SALARIO: {funcionarios.ValorDoSalario()}");
                        Console.WriteLine($"CARGO: {funcionarios.Cargo}\n-");
                    }
                    Console.Write("DESEJA CONSULTAR NOVAMENTE? (S/N)....:");
                    while (true)
                    {
                        resposta = Console.ReadLine().ToUpper();
                        if (resposta == "S" || resposta == "N") break;
                        else Console.Write("!RESPOSTA INVALIDA!\nTENTE NOVAMENTE....:");
                    }
                    if (resposta == "N") break;
                }
                else
                {
                    Console.WriteLine("NOME NÃO ENCONTRADO");
                    Console.Write("DESEJA TENTAR NOVAMENTE? (S/N)....:");
                    while (true)
                    {                        
                        resposta = Console.ReadLine().ToUpper();
                        if (resposta == "S" || resposta == "N") break;
                        else Console.Write("!RESPOSTA INVALIDA!\nTENTE NOVAMENTE....:");
                    }
                    if (resposta == "N") break;
                    
                }
            }
           
            
           
            Console.ReadKey();
        }
        public void FiltrarFuncionariosPorSalario()
        {
            Console.WriteLine("*************************FILTRO DE FUNCIONÁRIOS*************************");

            while (true)
            {
                Console.Write("Informe o salário....:");
                string resposta;
                double salario = Convert.ToDouble(Console.ReadLine());
                var procurandoSalario = listaFuncionario.OrderBy(n => n.Salario > salario).ToList();
                if (procurandoSalario != null)
                {
                    foreach (var funcionarios in procurandoSalario)
                    {
                        Console.WriteLine($"NOME: {funcionarios.Nome}");
                        Console.WriteLine($"GÊNERO: {funcionarios.Genero}");
                        Console.WriteLine($"DATA DE NASCIMENTO: {funcionarios.DataNascimento}");
                        Console.WriteLine($"CPF: {funcionarios.Cpf}");
                        Console.WriteLine($"SALARIO: {funcionarios.ValorDoSalario()}");
                        Console.WriteLine($"CARGO: {funcionarios.Cargo}\n-");
                    }
                }
                else
                {
                    Console.WriteLine($"NENHUMA SALÁRIO MAIOR QUE {salario.ToString("C2")} ENCONTRADO");
                    Console.Write("DESEJA TENTAR NOVAMENTE? (S/N)....:");
                    while (true)
                    {
                        resposta = Console.ReadLine().ToUpper();
                        if (resposta == "S" || resposta == "N") break;
                        else Console.Write("!RESPOSTA INVALIDA!\nTENTE NOVAMENTE....:");
                    }
                    if (resposta == "N") break;

                }
            }
            Console.ReadKey();
        }
        

      
        
        

    }
}
