﻿using SistemaDeGestaoDeFranquiasJava.RegrasDeGestao;
using System.Runtime.InteropServices;

List<Franquia> franquia = new List<Franquia>();
int posicao = 1;

void CadastrarFranquia()
{
    int requisito = 0;
    while (requisito == 0)
    {
        Console.Clear();
        Console.WriteLine("*************************CADASTRAR FRANQUIA*************************\n");

        Console.Write("Informe o nome fantasia da franquia: ");
        var nomeFantasia = Console.ReadLine();
        Console.WriteLine("\nTIPOS DE FRANQUIA");
        Console.WriteLine("\n1 - PEQUENA\n2 - MEDIA\n3 - MEDIA ALTA\n4 - ALTA\n5 - LUXO");
        Console.Write("Informe o número correspondente a sua escolha: ");
        var tipoFranquia = Console.ReadLine().ToUpper();
        if(tipoFranquia == "1") tipoFranquia = "PEQUENA";
        else if (tipoFranquia == "2") tipoFranquia = "MEDIA";
        else if (tipoFranquia == "3") tipoFranquia = "MEDIA ALTA";
        else if (tipoFranquia == "4") tipoFranquia = "ALTA";
        else if (tipoFranquia == "5") tipoFranquia = "LUXO";

        Franquia blocoFranquia = new Franquia(posicao, nomeFantasia, tipoFranquia);
        franquia.Add(blocoFranquia);
        posicao++;
        Console.WriteLine("\nFRANQUIA CADASTRADA!\n");
        Console.Write("Deseja cadastrar outra franquia? (0->SIM/1->NÃO)");
        requisito = Convert.ToInt32(Console.ReadLine());

    }//Fim while
}//Fim CadastrarFranquia

Franquia SelecionarFranquia()
{
    Console.WriteLine("*************************SELECIONAR FRANQUIA*************************\n\n");
    Console.WriteLine("FRANQUIAS DISPONIVEIS: ");
    foreach (var franquias in franquia)
    {
        Console.WriteLine($"NOME FANTASIA: {franquias.NomeFantasia}");
        Console.WriteLine($"TIPO DA FRANQUIA: {franquias.TipoFranquia}\n");
    }
    var nomeFantasia = Console.ReadLine().ToUpper();
    var fantasiaSelecionada = franquia.Where(a => a.NomeFantasia.ToUpper() == nomeFantasia).FirstOrDefault();

    if (fantasiaSelecionada == null)
    {
        Console.WriteLine("FRANQUIA INEXISTENTE");
        Console.ReadKey();
    }

    return fantasiaSelecionada;
}//Fim SelecionarFranquia

while (true)
{
    Console.WriteLine("*************************FRANQUIA ZYZ*************************\n\n");
    Console.WriteLine("1 - CADASTRAR FRANQUIA" +
        "\n2 - CADASTRAR FUNCIONÁRIOS\n3 - CONSULTAR FUNCIONÁRIOS DE UMA FRANQUIA");

    Console.Write("OPÇÃO N°......:");
    int escolha = Convert.ToInt32(Console.ReadLine());

    switch (escolha)
    {
        case 1: { CadastrarFranquia(); break; }
        case 2: 
            {
                var bloco = SelecionarFranquia();
                if(bloco != null) franquia.Where(a => a == bloco).FirstOrDefault().CadastrarFuncionario();
                break; 
            }
        case 3:
            {

                break;
            }
    }
}
