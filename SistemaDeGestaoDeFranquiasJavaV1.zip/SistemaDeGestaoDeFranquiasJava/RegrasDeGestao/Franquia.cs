﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaDeGestaoDeFranquiasJava.RegrasDeGestao
{
    public class Franquia
    {
        public string NomeFantasia {  get; set; }
        public string TipoFranquia { get; set; }
        public double ValorRendimento { get; set; }
        public double ValorAPagar {  get; set; }
        public int Id { get; set; }

        public int requisito = 0;
        public int condicao = 0;

        List<Funcionario> ListaFuncionario { get; set; }

        public Franquia (int id, string nomeFantasia, string tipoFranquia)
        {
            this.Id = id;
            this.NomeFantasia = nomeFantasia;
            this.TipoFranquia = tipoFranquia;

            ListaFuncionario = new List<Funcionario> ();
            
        }
        public void CadastrarFuncionario()
        {
            while (requisito == 0)
            {
                Console.Clear();
                Console.WriteLine("*************************CADASTRAR FUNCIONARIO*************************\n\n");
                Funcionario funcionario = new Funcionario ();


                Console.Write("Nome....:");
                funcionario.Nome = Console.ReadLine();
                Console.Write("\nGenero....:");
                funcionario.Genero = Console.ReadLine();
                Console.Write("\nEX:(dd/mm/yyyy)\nData de nascimento....:");
                funcionario.DataNascimento = Convert.ToDateTime(Console.ReadLine());
                Console.Write("\nCPF....:");
                funcionario.Cpf = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("\nINSIRA O NUMERO CORRESPONDENTE AO CARGO DESEJADO....:");
                Console.WriteLine("1 - GERENTE \n2 - CONTADOR \n3 - SECRETARIO \n4 - VENDEDOR \n" +
                    "5 - AUXILIAR DE SERVIÇOS GERAIS");
               while (true)
                {
                    funcionario.Cargo = Console.ReadLine();
                    if (funcionario.Cargo == "1" || funcionario.Cargo == "2" || funcionario.Cargo == "3" || funcionario.Cargo == "4" || funcionario.Cargo == "5") break;
                    else Console.Write("\n!CARGO FALSO! INSIRA NOVAMENTE:");
                }
                if (funcionario.Cargo == "1") funcionario.Cargo = "GERENTE";
                else if (funcionario.Cargo == "2") funcionario.Cargo = "CONTADOR";
                else if (funcionario.Cargo == "3") funcionario.Cargo = "SECRETARIO";
                else if (funcionario.Cargo == "4") funcionario.Cargo = "VENDEDOR";
                else if (funcionario.Cargo == "5") funcionario.Cargo = "AUXILIAR";

                condicao++;              

                if (condicao == 7)
                {
                    Console.WriteLine("\n7 FUNCIONÁRIOS REGISTRADOS!!!");                    
                }
                else if (condicao < 51)
                {
                    ListaFuncionario.Add (funcionario);
                    if (condicao > 7)
                    {
                        Console.WriteLine("DESEJA CONTINUAR CADASTRANDO FUNCIONÁRIOS? (0->SIM/1->NÃO)");
                        requisito = Convert.ToInt32(Console.ReadLine());
                    }
                    Console.WriteLine("DESEJA CONTINUAR CADASTRANDO FUNCIONÁRIOS? (0->SIM/1->NÃO)");
                    requisito = Convert.ToInt32(Console.ReadLine());
                }
                else if (condicao == 50) Console.WriteLine("!MÁXIMO DE FUNCIONÁRIOS CADASTRADOS!"); requisito = 1;             
                
            }//Fim do while
        }//Fim CadastrarFuncionario
    }
}
