﻿using SistemaDeGestaoDeFranquiasJava.RegrasDeGestao;
using System.Runtime.InteropServices;

List<Franquia> franquia = new List<Franquia>();
int posicao = 1;

void CadastrarFranquia()
{
    int requisito = 0;
    while (requisito == 0)
    {
        Console.Clear();
        Console.WriteLine("*************************CADASTRAR FRANQUIA*************************\n");

        Console.Write("Informe o nome fantasia da franquia: ");
        var nomeFantasia = Console.ReadLine();
        Console.WriteLine("\nTIPOS DE FRANQUIA");
        Console.WriteLine("\n1 - PEQUENA\n2 - MEDIA\n3 - MEDIA ALTA\n4 - ALTA\n5 - LUXO");
        Console.Write("Informe o número correspondente a sua escolha: ");
        var tipoFranquia = Console.ReadLine().ToUpper();
        if(tipoFranquia == "1") tipoFranquia = "PEQUENA";
        else if (tipoFranquia == "2") tipoFranquia = "MEDIA";
        else if (tipoFranquia == "3") tipoFranquia = "MEDIA ALTA";
        else if (tipoFranquia == "4") tipoFranquia = "ALTA";
        else if (tipoFranquia == "5") tipoFranquia = "LUXO";

        Franquia blocoFranquia = new Franquia(posicao, nomeFantasia, tipoFranquia);
        franquia.Add(blocoFranquia);
        posicao++;
        Console.WriteLine("\nFRANQUIA CADASTRADA!\n");
        Console.Write("Deseja cadastrar outra franquia? (0->SIM/1->NÃO)");
        requisito = Convert.ToInt32(Console.ReadLine());

    }//Fim while
}//Fim CadastrarFranquia

Franquia SelecionarFranquia()
{
    Console.WriteLine("*************************SELECIONAR FRANQUIA*************************\n\n");
    Console.WriteLine("FRANQUIAS DISPONIVEIS: ");
    foreach (var franquias in franquia)
    {
        Console.WriteLine($"NOME FANTASIA: {franquias.NomeFantasia}");
        Console.WriteLine($"TIPO DA FRANQUIA: {franquias.TipoFranquia}\n");
    }
    var nomeFantasia = Console.ReadLine().ToUpper();
    var fantasiaSelecionada = franquia.Where(a => a.NomeFantasia.ToUpper() == nomeFantasia).FirstOrDefault();

    if (fantasiaSelecionada == null)
    {
        Console.WriteLine("FRANQUIA INEXISTENTE");
        Console.ReadKey();
    }

    return fantasiaSelecionada;
}//Fim SelecionarFranquia
void ConsultarFuncionario()
{
    Console.Clear();
    List<Funcionario> todosFuncionarios = new List<Funcionario>();
    foreach (var funcionarios in franquia)
    {
        todosFuncionarios.AddRange(funcionarios.ListaFuncionario);
    }
    Console.Write("*************************CONSULTAR FUNCIONÁRIO PELO NOME*************************\n\nNOME: ");
    var acharNome = Console.ReadLine();
    foreach (var funcionario in todosFuncionarios.OrderBy(n => n.Nome == acharNome).ToList())
    {
        Console.Clear();
        Console.WriteLine($"NOME: {funcionario.Nome}");
        Console.WriteLine($"GÊNERO: {funcionario.Genero}");
        Console.WriteLine($"DATA DE NASCIMENTO: {funcionario.DataNascimento}");
        Console.WriteLine($"CPF: {funcionario.Cpf}");
        Console.WriteLine($"SALARIO: {funcionario.ValorDoSalario}");
        Console.WriteLine($"CARGO: {funcionario.Cargo}\n-");        
    }
    
    Console.ReadKey();
}
void FiltrarFuncionariosPorNome()
{
    Console.Clear();
    List<Funcionario> todosFuncionarios = new List<Funcionario>();
    foreach (var funcionarios in franquia)
    {
        todosFuncionarios.AddRange(funcionarios.ListaFuncionario);
    }
    Console.Write("*************************FILTRAR FUNCIONÁRIOS PELO NOME*************************\n\nNOME: ");
    var acharNome = Console.ReadLine();
    foreach (var funcionario in todosFuncionarios.OrderBy(n => n.Nome.Contains(acharNome)).ToList())
    {
       
        Console.WriteLine($"NOME: {funcionario.Nome}");
        Console.WriteLine($"GÊNERO: {funcionario.Genero}");
        Console.WriteLine($"DATA DE NASCIMENTO: {funcionario.DataNascimento}");
        Console.WriteLine($"CPF: {funcionario.Cpf}");
        Console.WriteLine($"SALARIO: {funcionario.Salario}");
        Console.WriteLine($"CARGO: {funcionario.Cargo}\n-");
    }

    Console.ReadKey();
}
void FiltrarFuncionariosPorSalario()
{
    Console.Clear();
    List<Funcionario> todosFuncionarios = new List<Funcionario>();
    foreach (var funcionarios in franquia)
    {
        todosFuncionarios.AddRange(funcionarios.ListaFuncionario);
    }
    Console.Write("*************************FILTRAR FUNCIONÁRIOS POR SALÁRIO*************************\n\nSALÁRIO: ");
    double salarioFiltro = Convert.ToDouble(Console.ReadLine());
    foreach (var funcionario in todosFuncionarios.OrderBy(n => n.Salario > salarioFiltro).ToList())
    {

        Console.WriteLine($"NOME: {funcionario.Nome}");
        Console.WriteLine($"GÊNERO: {funcionario.Genero}");
        Console.WriteLine($"DATA DE NASCIMENTO: {funcionario.DataNascimento}");
        Console.WriteLine($"CPF: {funcionario.Cpf}");
        Console.WriteLine($"SALARIO: {funcionario.Salario}");
        Console.WriteLine($"CARGO: {funcionario.Cargo}\n-");
    }

    Console.ReadKey();
}
void FiltrarFranquiasPorTipo()
{
    Console.Clear();
    List<Franquia> todasFranquias = new List<Franquia>();
    foreach (var funcionarios in franquia)
    {
        todasFranquias.AddRange(franquia);
    }
    Console.Write("*************************FILTRAR FRANQUIAS POR TIPO*************************\n1 - PEQUENA\n2 - MEDIA\n3 - MEDIA ALTA\n4 - ALTA\n5 LUXO\nTIPO: ");
    string tipoEscolhido = Console.ReadLine();
    switch (tipoEscolhido)
    {
        case "1":
            {
                tipoEscolhido = "PEQUENA";
                break;
            }
        case "2":
            {
                tipoEscolhido = "MEDIA";
                break;
            }
        case "3":
            {
                tipoEscolhido = "MEDIA ALTA";
                break;
            }
        case "4":
            {
                tipoEscolhido = "ALTA";
                break;
            }
        case "5":
            {
                tipoEscolhido = "LUXO";

                break;
            }
    }
    Console.WriteLine("LISTA DE FRANQUIAS " + tipoEscolhido);
    foreach (var franquia in todasFranquias.Where(t => t.TipoFranquia.Contains(tipoEscolhido)).ToList())
    {
        if (franquia.TipoFranquia == tipoEscolhido)
        {
            Console.WriteLine(franquia.NomeFantasia);
        }
        
    }
    

    Console.ReadKey();
}
void ListarTodosGerentes()
{

}

while (true)
{
    Console.WriteLine("*************************FRANQUIA ZYZ*************************\n\n");
    Console.WriteLine("1 - CADASTRAR FRANQUIA" +
        "\n2 - CADASTRAR FUNCIONÁRIOS\n3 - CONSULTAR FUNCIONÁRIOS DE UMA FRANQUIA\n" +
        "4 - CONSULTAR FUNCIONÁRIO PELO NOME\n5 - FILTRAR FUNCIONÁRIOS POR NOME\n6 - FILTRAR FUNCIONÁRIOS POR SALÁRIO\n" +
        "7 - FILTRAR FRANQUIAS POR TIPO");

    Console.Write("OPÇÃO N°......:");
    int escolha = Convert.ToInt32(Console.ReadLine());

    switch (escolha)
    {
        case 1: { CadastrarFranquia(); break; }
        case 2: 
            {
                var bloco = SelecionarFranquia();
                if(bloco != null) franquia.Where(a => a == bloco).FirstOrDefault().CadastrarFuncionario();
                break; 
            }
        case 3:
            {
                var bloco = SelecionarFranquia();
                if (bloco != null) franquia.Where(a => a == bloco).FirstOrDefault().ConsultarDadosDaFranquia();
           
                break;
            }
        case 4:
            {
                ConsultarFuncionario();
                
                break;
            }
        case 5:
            {
                FiltrarFuncionariosPorNome();
                break;
            }
        case 6:
            {
                FiltrarFuncionariosPorSalario();
                break;
            }
        case 7:
            {
                FiltrarFranquiasPorTipo();
                break;
            }
        case 9:
            {
                ListarTodosGerentes().Where();
                break;
            }

    }
}
