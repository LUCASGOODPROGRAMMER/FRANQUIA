﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaDeGestaoDeFranquiasJava.RegrasDeGestao
{
    public class Funcionario
    {
        public string Nome { get; set; }
        public string Genero { get; set; }
        public DateTime DataNascimento { get; set; }
        public int Cpf { get; set; }
        public double Salario { get; set; }
        public string Cargo { get; set; }

        public void ValorDoSalario()
        {           
            
                if (Cargo == "GERENTE") Salario = 12000;
                else if (Cargo == "CONTADOR") Salario = 10000;
                else if (Cargo == "SECRETARIO") Salario = 8000;
                else if (Cargo == "VENDEDOR") Salario = 5000;
                else if (Cargo == "AUXILIAR") Salario = 4500;
            return;
        }
       

    }
}
